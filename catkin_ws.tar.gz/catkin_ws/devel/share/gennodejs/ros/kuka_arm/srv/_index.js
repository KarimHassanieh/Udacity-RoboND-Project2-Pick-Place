
"use strict";

let CalculateIK = require('./CalculateIK.js')

module.exports = {
  CalculateIK: CalculateIK,
};
